import json
import os
import re
import shutil
import sys
import time
import base64
import shlex
import requests
import yt_dlp
from PIL import Image
import io

# 设置标准输出和标准错误流编码为UTF-8
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')
sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8')

# 全局变量，将从 config.json 加载
OWNER_NAME = ""
REMOVE_FILE = True
DEFAULT_TID = 27
MONITOR_INTERVAL_SECONDS = 3600
YOUTUBE_PLAYLIST_URL = "" # 新增，用于存储监控的YouTube URL

# 其他固定配置
LineN = "qn"  # 线路 cos bda2 qn ws kodo
# COOKIES_FROM_BROWSER = ("firefox",) # 暂时未用到，如果 biliup 需要，可能在此处配置，目前 yt_dlp 和 biliup 都直接读取 cookies.txt
URL_LIST_FILE = "url_list.json" # 用于存储待上传和已上传视频状态的列表

def load_config():
    """
    加载配置文件 config.json 中的设置。
    如果文件不存在，则创建默认配置。
    """
    global OWNER_NAME, REMOVE_FILE, DEFAULT_TID, MONITOR_INTERVAL_SECONDS, YOUTUBE_PLAYLIST_URL
    config_path = "config.json"
    default_config = {
        "youtube_playlist_url": "YOUR_YOUTUBE_PLAYLIST_OR_CHANNEL_URL_HERE", # 替换为此处
        "monitor_interval_seconds": 3600,
        "default_tid": 27,
        "owner_name": "深夜好梦呀",
        "remove_file_after_upload": True
    }

    if not os.path.exists(config_path):
        print(f"配置文件 {config_path} 不存在，创建默认配置。")
        with open(config_path, "w", encoding="utf-8") as f:
            json.dump(default_config, f, ensure_ascii=False, indent=4)
        
        # 使用默认值启动，但会提示用户配置URL
        OWNER_NAME = default_config["owner_name"]
        REMOVE_FILE = default_config["remove_file_after_upload"]
        DEFAULT_TID = default_config["default_tid"]
        MONITOR_INTERVAL_SECONDS = default_config["monitor_interval_seconds"]
        YOUTUBE_PLAYLIST_URL = default_config["youtube_playlist_url"]

        print("请手动编辑 config.json 文件，填写您的 YouTube 播放列表或频道URL后重新运行脚本。")
        sys.stdout.flush() # 强制刷新输出
        sys.exit(1) # 退出程序，强制用户配置URL
    else:
        with open(config_path, "r", encoding="utf-8") as f:
            config = json.load(f)
        
        # 加载配置
        YOUTUBE_PLAYLIST_URL = config.get("youtube_playlist_url", default_config["youtube_playlist_url"])
        if not YOUTUBE_PLAYLIST_URL or YOUTUBE_PLAYLIST_URL == default_config["youtube_playlist_url"]:
            print(f"配置文件 {config_path} 中的 'youtube_playlist_url' 未设置或保留默认值。请编辑该文件以设置您的 YouTube 播放列表或频道URL。")
            sys.stdout.flush() # 强制刷新输出
            sys.exit(1) # 强制用户配置URL
        
        OWNER_NAME = config.get("owner_name", default_config["owner_name"])
        REMOVE_FILE = config.get("remove_file_after_upload", default_config["remove_file_after_upload"])

        # 尝试将 default_tid 转换为整数，如果失败则使用默认值
        try:
            DEFAULT_TID = int(config.get("default_tid", default_config["default_tid"]))
        except ValueError:
            print(f"警告: config.json 中的 'default_tid' 值无效，将使用默认值 {default_config['default_tid']}。")
            DEFAULT_TID = default_config["default_tid"]

        # 尝试将 monitor_interval_seconds 转换为整数，如果失败则使用默认值
        try:
            MONITOR_INTERVAL_SECONDS = int(config.get("monitor_interval_seconds", default_config["monitor_interval_seconds"]))
            if MONITOR_INTERVAL_SECONDS <= 0:
                print(f"警告: 'monitor_interval_seconds' 必须大于0，将使用默认值 {default_config['monitor_interval_seconds']}。")
                MONITOR_INTERVAL_SECONDS = default_config["monitor_interval_seconds"]
        except ValueError:
            print(f"警告: 'monitor_interval_seconds' 值无效，将使用默认值 {default_config['monitor_interval_seconds']}。")
            MONITOR_INTERVAL_SECONDS = default_config["monitor_interval_seconds"]

    print(f"配置加载完成: OWNER_NAME='{OWNER_NAME}', REMOVE_FILE={REMOVE_FILE}, DEFAULT_TID={DEFAULT_TID}, MONITOR_INTERVAL_SECONDS={MONITOR_INTERVAL_SECONDS}秒, YOUTUBE_PLAYLIST_URL='{YOUTUBE_PLAYLIST_URL}'")

def escape_description(description):
    """
    转义描述字符串，使其适合作为命令行参数。
    """
    return shlex.quote(description)

def get_double(s):
    """
    将字符串用双引号包裹。
    """
    return '"' + s + '"'

def cover_webp_to_jpg(webp_path, jpg_path):
    """
    将 WebP 格式的封面图片转换为 JPG 格式。
    """
    try:
        im = Image.open(webp_path).convert("RGB")
        im.save(jpg_path, "jpeg")
        im.close()
        print(f"封面图片从 {webp_path} 转换为 {jpg_path} 成功。")
    except Exception as e:
        print(f"转换封面图片失败: {webp_path} -> {e}")

def download(youtube_url, folder_name):
    """
    下载YouTube视频。
    """
    output_template = os.path.join(".", "videos", str(folder_name), "%(id)s.mp4") # 使用 join 构建路径
    ydl_opts = {
        "outtmpl": output_template,
        "cookiefile": "cookies.txt",
        "restrictfilenames": True, # 防止文件名中含有特殊字符，避免路径问题
        "writedescription": False, # 不写入描述文件
        "writeinfojson": False,    # 不写入信息json文件
        "writesubtitles": False,   # 不写入字幕文件
        "quiet": True,             # 隐藏yt-dlp的输出，只显示错误
        "no_warnings": True,       # 隐藏警告
        "postprocessors": [{
            "key": "FFmpegVideoConvertor",
            "preferedformat": "mp4",
        }],
    }

    print(f"开始下载视频: {youtube_url} 到 '{output_template}'.")
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            ydl.download([youtube_url])
        print(f"视频 {youtube_url} 下载成功。")
    except yt_dlp.utils.DownloadError as e:
        print(f"下载视频 {youtube_url} 失败: {e}")
        raise # 重新抛出异常以便上层捕获

def get_info(url):
    """
    获取YouTube视频的元数据信息。
    """
    ydl_opts = {
        "cookiefile": "cookies.txt",
        "skip_download": True, # 不下载视频
        "quiet": True,
        "no_warnings": True,
        "noplaylist": True, # 确保不处理播放列表，只处理单个视频信息
    }
    print(f"正在获取视频信息: {url}")
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info = ydl.extract_info(url, download=False)
            return info
    except yt_dlp.utils.DownloadError as e:
        print(f"获取视频 {url} 信息失败: {e}")
        return None # 返回None表示获取信息失败

def getVideoPath(id_):
    """
    根据视频ID获取本地视频文件的完整路径。
    """
    path = os.path.join(".", "videos", str(id_))
    for root, dirs, files in os.walk(path):
        for file in files:
            # 查找以ID开头且为.mp4后缀的文件
            if file.startswith(id_) and file.endswith(".mp4"):
                return os.path.join(root, file)
    print(f"未找到视频文件在路径: {path}，ID: {id_}")
    return None # 未找到视频文件

def download_image(url, id_):
    """
    下载视频封面图片。
    """
    output_dir = os.path.join(".", "videos", str(id_))
    os.makedirs(output_dir, exist_ok=True) # 确保目录存在
    filepath = os.path.join(output_dir, "cover.webp")
    print(f"正在下载封面图片: {url} 到 {filepath}")
    
    try:
        r = requests.get(url, stream=True, timeout=10) # 增加超时时间
        r.raise_for_status() # 检查HTTP请求是否成功
        with open(filepath, "wb") as f:
            for chunk in r.iter_content(chunk_size=8192): # 减小chunk_size
                if chunk:
                    f.write(chunk)
        print(f"封面图片下载成功。")
    except requests.exceptions.RequestException as e:
        print(f"下载封面图片失败: {e}")
        raise # 重新抛出异常

def judge_chs(title):
    """
    判断标题是否包含中文字符。
    """
    for i in title:
        if "\u4e00" <= i <= "\u9fa5":
            return True
    return False

def get_base64(string):
    """
    将字符串进行Base64编码。
    """
    return str(base64.b64encode(string.encode("utf-8")).decode("utf-8"))

def get_base64_twice(string):
    """
    将字符串进行两次Base64编码。
    """
    i = 0
    while i < 2:
        string = get_base64(string)
        i += 1
    return string

def get_chs_title(title):
    """
    处理中文标题，确保Base64编码后长度不超过80。
    现已被 `biliup_upload` 中的直接 `get_double(title)` 方式部分替代。
    此函数在当前脚本中可能不完全适用 biliup 的标题限制，因为 biliup 直接处理 utf-8 字符串。
    保留此函数以备未来需要对标题进行特定编码处理。
    """
    original_title = title
    while True:
        # 使用原始标题长度检查，因为 biliup 通常可以直接处理UTF-8标题，其长度计算方式与Base64不同
        # 实际B站标题限制是80字，如果转Base64会更长。这里可能是早期逻辑，暂时保留但其效果可能不符预期。
        # 如果需要严格控制ASCII字节长度（Base64后），则此逻辑有意义。
        # 但通常我们直接传原标题让 biliup 处理。
        if len(original_title.encode('utf-8')) > 80: # 假设B站限制是UTF-8编码的字节长度
            truncated_len = 0
            for i in range(len(original_title)):
                if len(original_title[:i+1].encode('utf-8')) > 80:
                    truncated_len = i
                    break
            if truncated_len > 0:
                original_title = original_title[:truncated_len]
            else: # 如果截断到空字符串
                original_title = ""
            
            if not original_title:
                print("警告: 标题过长，已截断为空。")
                return ""
            continue
        else:
            return original_title # 返回截断后的原始标题，而不是base64编码的

def get_chs_title_twice(title):
    """
    对中文标题进行两次处理。
    此函数在当前脚本中可能不完全适用 biliup 的标题限制，因为 biliup 直接处理 utf-8 字符串。
    """
    i = 0
    while i < 2:
        title = get_chs_title(title)
        i += 1
    return title

def cut_tags(tags):
    """
    截断标签，确保每个标签长度不超过20。
    """
    processed_tags = []
    for tag in tags:
        if len(tag.encode('utf-8')) > 20: # 同样以UTF-8字节长度为准
            truncated_tag = tag
            while len(truncated_tag.encode('utf-8')) > 20:
                truncated_tag = truncated_tag[:-1]
            processed_tags.append(truncated_tag)
            print(f"标签 '{tag}' 过长 (UTF-8字节), 已截断为 '{truncated_tag}'")
        else:
            processed_tags.append(tag)
    return processed_tags

def biliup_upload(vUrl, TID, title, dynamic_title, description, tags, videoPath, cover):
    """
    使用 biliup-rs 工具上传视频到B站。
    TID: 分区号
    title: 视频标题
    dynamic_title: 不再使用，因为B站动态不直接使用这个
    description: 视频描述
    tags: 标签列表
    videoPath: 视频文件路径
    cover: 封面图片路径
    """
    if not videoPath or not os.path.exists(videoPath):
        print(f"错误: 视频文件路径无效或文件不存在: {videoPath}")
        return False
    if not cover or not os.path.exists(cover):
        print(f"错误: 封面图片路径无效或文件不存在: {cover}")
        return False

    # 限制标题长度
    if len(title.encode('utf-8')) > 80:
        truncated_title = title
        while len(truncated_title.encode('utf-8')) > 80:
            truncated_title = truncated_title[:-1]
        print(f"警告: 标题 '{title}' 过长 (UTF-8字节), 已截断为 '{truncated_title}'")
        title = truncated_title
    
    # 限制描述长度
    if len(description.encode('utf-8')) > 250:
        truncated_description = description
        while len(truncated_description.encode('utf-8')) > 250:
            truncated_description = truncated_description[:-1]
        print(f"警告: 描述过长, 已截断。")
        description = truncated_description

    # 限制标签数量和长度
    tags = cut_tags(tags)
    if len(tags) > 10:
        tags = tags[:10]
        print(f"警告: 标签数量超过10个, 已截断为前10个。")

    strTags = ",".join(tags)

    # 使用 shlex.quote 来处理可能包含特殊字符的字符串参数
    # biliup 工具可以直接接受 UTF-8 字符串作为标题、描述和标签
    CMD_parts = [
        "./biliup", "upload",
        shlex.quote(videoPath),
        "--copyright", "1", # 默认版权为原创
        "--tag", shlex.quote(strTags),
        "--tid", str(TID),
        "--source", shlex.quote(vUrl),
        "--line", LineN,
        "--title", shlex.quote(title),
        "--desc", shlex.quote(description), # 添加描述参数
        "--cover", shlex.quote(cover)
    ]
    CMD = " ".join(CMD_parts)

    print("[🚀 原始标题]: ", title)
    print("[🚀 描述]: ", description)
    print("[🚀 标签]: ", strTags)
    print("[🚀 开始使用 biliup 上传，命令]:\n", CMD)
    
    try:
        # 使用 os.popen 获取输出，并实时打印
        with os.popen(CMD) as pipe:
            biliupOutput = pipe.read()
        
        print("[biliup output]:\n", biliupOutput)
        
        success = "投稿成功" in biliupOutput or "标题相同" in biliupOutput # 标题相同也视为成功，避免重复上传
        if success:
            print(f"视频 {title} (URL: {vUrl}) 上传成功或已存在。")
        else:
            print(f"视频 {title} (URL: {vUrl}) 上传失败。")
        return success
    except Exception as e:
        print(f"执行 biliup 命令时发生错误: {e}")
        return False

def process_video(vUrl, TID):
    """
    处理单个视频的下载、信息提取、上传流程。
    """
    print(f"\n>>>>>> 开始处理视频: {vUrl} <<<<<<")
    id_ = None # 初始化 id_，以防在异常处理中使用
    try:
        info = get_info(vUrl)
        if not info:
            print(f"无法获取视频 {vUrl} 的信息，跳过处理。")
            return False

        title = info.get("title", f"未知标题 - {vUrl}")
        author = info.get("uploader", "未知作者")
        id_ = info.get("id")
        description = info.get("description", "无描述").strip()
        tags = info.get("tags", [])
        cover = info.get("thumbnail")

        if not id_:
            print(f"错误: 无法获取视频 {vUrl} 的ID，跳过处理。")
            return False
        
        # 确保tags是列表
        if not isinstance(tags, list):
            tags = [str(tags)] if tags else []

        # 将作者和所有者名称添加到标签
        tags.append(author)
        tags.append(OWNER_NAME)
        # 移除重复标签并过滤空标签
        tags = list(set([tag.strip() for tag in tags if tag.strip()]))

        video_output_dir = os.path.join(".", "videos", str(id_))

        # 清理旧目录或创建新目录
        if os.path.exists(video_output_dir):
            print(f"发现旧目录 {video_output_dir}，正在清理...")
            shutil.rmtree(video_output_dir)
            print(f"旧目录 {video_output_dir} 清理完成。")
        os.makedirs(video_output_dir, exist_ok=True)
        print(f"创建临时目录: {video_output_dir}")

        download(vUrl, id_)
        download_image(cover, id_)
        
        cover_webp_path = os.path.join(video_output_dir, "cover.webp")
        cover_jpg_path = os.path.join(video_output_dir, "cover.jpg")
        
        if os.path.exists(cover_webp_path):
            cover_webp_to_jpg(cover_webp_path, cover_jpg_path)
        else:
            print(f"警告: 未找到webp封面文件 {cover_webp_path}。这可能是正常情况，尝试从原始URL下载封面。")
            # 重新尝试下载封面，如果 thumbnail 不是 webp 格式可能已经下载了 jpg/png
            # 或者如果 biliup 无法处理原始URL作为封面，此处会导致失败
            # 暂时保持逻辑，如果需要更健壮，可以尝试用 Requests 库下载并强制保存为 JPG
            download_image(cover, id_) # 再次尝试下载，如果下载的是jpg/png，则直接改名或确保后缀正确

            # 重新检查现在是否存在 jpg/png 封面，或者干脆只保留之前下载的封面。
            # 如果原始thumbnail不是webp，那么第一次下载image可能就是jpg/png
            # 这里简单处理，如果webp不存在，就认为已经有jpg了，或者让biliup去处理封面路径。
            found_image = False
            for f in os.listdir(video_output_dir):
                if f.startswith("cover.") and (f.endswith(".jpg") or f.endswith(".jpeg") or f.endswith(".png")):
                    cover_jpg_path = os.path.join(video_output_dir, f) # 找到已下载的真实封面
                    found_image = True
                    break
            if not found_image: # 如果仍然没有jpg/png文件
                 print(f"错误：未能找到或生成视频 {id_} 的封面图片。")
                 return False
        
        videoPath = getVideoPath(id_)
        if not videoPath:
            print(f"错误: 视频文件下载成功但找不到路径: {video_output_dir}，跳过上传。")
            return False
        
        # dynamic_title 在 biliup 上传中通常不直接使用，可以传递 title 或其他固定值
        # 这里为了保持函数签名一致，仍传递，但实际上传时会忽略
        success = biliup_upload(vUrl, TID, title, title, description, tags, videoPath, cover_jpg_path)
        
        if success and REMOVE_FILE:
            print(f"视频 {vUrl} 上传成功，正在删除临时文件: {video_output_dir}")
            shutil.rmtree(video_output_dir)
            print(f"临时文件删除完成: {video_output_dir}")
        elif not success:
            print(f"视频 {vUrl} 上传失败，保留临时文件在: {video_output_dir} 以供调试。")
        
        return success
    except Exception as e:
        print(f"处理视频 {vUrl} 时发生错误: {e}")
        # 如果出错，保留文件以便检查问题
        if id_ and os.path.exists(os.path.join(".", "videos", str(id_))):
            print(f"由于错误，保留临时文件在: {os.path.join('.', 'videos', str(id_))} 以供调试。")
        return False

def load_url_list():
    """
    从 JSON 文件加载URL列表。
    """
    if os.path.exists(URL_LIST_FILE):
        try:
            with open(URL_LIST_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except json.JSONDecodeError as e:
            print(f"加载 {URL_LIST_FILE} 出错，文件可能损坏: {e}")
            print(f"将创建新的 {URL_LIST_FILE}。")
            return []
    return []

def save_url_list(url_list):
    """
    将URL列表保存到 JSON 文件。
    """
    with open(URL_LIST_FILE, "w", encoding="utf-8") as f:
        json.dump(url_list, f, ensure_ascii=False, indent=4)

def get_latest_playlist_videos(playlist_url):
    """
    获取 YouTube 播放列表或频道中的所有视频URL。
    yt_dlp 可以直接处理频道URL，并将其视为一个播放列表。
    """
    print(f"正在从 YouTube 获取播放列表/频道信息: {playlist_url}")
    ydl_opts = {
        "cookiefile": "cookies.txt",
        "flat_playlist": True,  # 只获取播放列表条目，不下载
        "dump_single_json": True, # 输出单个JSON对象
        "extract_flat": True, # 避免深入提取每个视频的详细信息，只获取URL和ID
        "skip_download": True, # 确保不下载
        "quiet": True,
        "no_warnings": True,
        "ignoreerrors": True, # 忽略单个视频的错误，继续处理列表中的其他视频
    }
    
    video_urls = set()
    try:
        with yt_dlp.YoutubeDL(ydl_opts) as ydl:
            info_dict = ydl.extract_info(playlist_url, download=False)
        
        if "entries" in info_dict:
            for entry in info_dict["entries"]:
                # 检查 entry 是否为 None 或是否有 'url' 键
                if entry and "url" in entry and entry["url"].startswith("https://www.youtube.com/watch?v="):
                    video_urls.add(entry["url"])
                else:
                    print(f"警告: 发现播放列表/频道中有一个无效或非YouTube的条目，已跳过: {entry.get('url', 'N/A')}")
        else:
            print(f"未从 {playlist_url} 获取到任何播放列表条目。请检查URL是否正确。")
    except yt_dlp.utils.DownloadError as e:
        print(f"获取播放列表/频道信息失败: {e}")
    except Exception as e:
        print(f"获取播放列表/频道信息时发生意外错误: {e}")
    
    print(f"从播放列表/频道获取到 {len(video_urls)} 个视频URL。")
    return video_urls

def mode_single_video():
    """
    处理单视频上传模式。
    """
    url = input("请输入视频URL: ")
    tid_input = input(f"请输入分区代码 (默认{DEFAULT_TID}): ")
    tid = DEFAULT_TID
    if tid_input:
        try:
            tid = int(tid_input)
        except ValueError:
            print(f"输入的分区代码无效，将使用默认值 {DEFAULT_TID}。")
    process_video(url, tid)

def mode_video_list():
    """
    处理视频列表或频道模式，获取所有视频URL并保存到url_list.json。
    修改为使用yt_dlp的Python API直接获取信息，避免使用os.system和临时文件。
    """
    url_to_fetch = input("请输入视频列表或频道URL: ")
    print(f"正在从 {url_to_fetch} 获取视频列表信息...")

    # 使用 get_latest_playlist_videos 函数获取URL列表
    new_video_urls = get_latest_playlist_videos(url_to_fetch)

    if not new_video_urls:
        print("未找到任何有效的YouTube视频URL。请检查提供的URL是否正确。")
        return

    # 加载现有的url_list，以避免重复添加
    existing_url_list = load_url_list()
    existing_urls_set = {entry["url"] for entry in existing_url_list}
    
    new_urls_to_add = []
    for url in new_video_urls:
        if url not in existing_urls_set:
            new_urls_to_add.append({"url": url, "status": "no", "count": 0})
    
    if new_urls_to_add:
        url_list = existing_url_list + new_urls_to_add
        save_url_list(url_list)
        print(f"已添加到待上传列表中的新视频数量: {len(new_urls_to_add)}")
        print("以下是需要上传的视频URL列表 (包含之前未完成的):")
    else:
        url_list = existing_url_list
        print("未发现新的视频URL，所有视频可能已被添加或已存在于列表中。")
        print("以下是需要上传的视频URL列表:")

    for entry in url_list:
        print(f" - {entry['url']} (状态: {entry['status']}, 尝试次数: {entry['count']})")

    confirm = input("请确认以上URL是否正确并开始上传 (yes/no): ")
    if confirm.lower() != "yes":
        print("操作已取消。")
        return
    
    tid_input = input(f"请输入分区代码 (默认{DEFAULT_TID}): ")
    tid = DEFAULT_TID
    if tid_input:
        try:
            tid = int(tid_input)
        except ValueError:
            print(f"输入的分区代码无效，将使用默认值 {DEFAULT_TID}。")
    
    current_url_list = load_url_list() # 重新加载以确保是最新的
    for i, entry in enumerate(current_url_list):
        if entry["status"] == "no":
            print(f"开始处理视频: {entry['url']}")
            for attempt_count in range(2):  # 尝试2次
                success = process_video(entry["url"], tid)
                if success:
                    current_url_list[i]["status"] = "yes"
                    print(f"视频 {entry['url']} 上传成功。")
                    break
                else:
                    current_url_list[i]["count"] += 1
                    print(f"视频 {entry['url']} 上传失败 (第 {attempt_count + 1} 次尝试)。")
            if current_url_list[i]["status"] == "no":
                print(f"视频 {entry['url']} 两次尝试后仍上传失败。")
            save_url_list(current_url_list) # 每次更新都保存，防止程序中断
        else:
            print(f"视频 {entry['url']} 已上传，跳过。")

def mode_resume_upload():
    """
    处理断点续传模式。
    """
    tid_input = input(f"请输入分区代码 (默认{DEFAULT_TID}): ")
    tid = DEFAULT_TID
    if tid_input:
        try:
            tid = int(tid_input)
        except ValueError:
            print(f"输入的分区代码无效，将使用默认值 {DEFAULT_TID}。")
    
    url_list = load_url_list()
    
    # 过滤出未上传的视频
    pending_uploads = [entry for entry in url_list if entry["status"] == "no"]

    if not pending_uploads:
        print("没有待上传的视频，所有视频已完成或列表为空。")
        return

    print("以下视频将继续上传:")
    for entry in pending_uploads:
        print(f" - {entry['url']} (尝试次数: {entry['count']})")
    
    confirm = input("请确认继续上传以上视频 (yes/no): ")
    if confirm.lower() != "yes":
        print("操作已取消。")
        return

    # 从当前列表开始尝试上传
    for i, entry in enumerate(url_list):
        if entry["status"] == "no":
            print(f"开始处理视频 (断点续传): {entry['url']}")
            for attempt_count in range(2): # 尝试2次
                success = process_video(entry["url"], tid)
                if success:
                    url_list[i]["status"] = "yes"
                    print(f"视频 {entry['url']} 上传成功。")
                    break
                else:
                    url_list[i]["count"] += 1
                    print(f"视频 {entry['url']} 上传失败 (第 {attempt_count + 1} 次尝试)。")
            if url_list[i]["status"] == "no":
                print(f"视频 {entry['url']} 两次尝试后仍上传失败。")
            save_url_list(url_list) # 每次更新都保存，防止程序中断

def mode_auto_monitor():
    """
    自动监控 YouTube 播放列表/频道，下载并上传新视频。
    """
    if not YOUTUBE_PLAYLIST_URL or YOUTUBE_PLAYLIST_URL == "YOUR_YOUTUBE_PLAYLIST_OR_CHANNEL_URL_HERE":
        print("错误: 在 config.json 中未配置 'youtube_playlist_url'，无法进入自动监控模式。")
        sys.stdout.flush()
        return

    print(f"进入自动监控模式。将每隔 {MONITOR_INTERVAL_SECONDS} 秒检查一次新视频。")
    print(f"监控的YouTube URL: {YOUTUBE_PLAYLIST_URL}")
    print(f"默认B站分区TID: {DEFAULT_TID}")

    while True:
        print(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] 正在检查新的YouTube视频...")
        
        latest_youtube_urls = get_latest_playlist_videos(YOUTUBE_PLAYLIST_URL)
        if not latest_youtube_urls:
            print("未能获取到最新的YouTube视频列表，将在下次循环中重试。")
            time.sleep(MONITOR_INTERVAL_SECONDS)
            continue

        existing_url_list = load_url_list()
        existing_urls_set = {entry["url"] for entry in existing_url_list}
        
        new_videos_found = False
        for url in latest_youtube_urls:
            if url not in existing_urls_set:
                print(f"发现新视频: {url}，添加到待上传列表。")
                existing_url_list.append({"url": url, "status": "no", "count": 0})
                new_videos_found = True
        
        if new_videos_found:
            save_url_list(existing_url_list)
            print("已更新待上传视频列表。")
        else:
            print("未发现新的视频。")

        # 尝试上传所有状态为 "no" 的视频
        pending_uploads_count = 0
        for i, entry in enumerate(existing_url_list):
            if entry["status"] == "no":
                if entry["count"] < 2: # 限定重试次数，避免无限循环失败任务
                    print(f"开始处理待上传视频: {entry['url']} (已尝试 {entry['count']} 次)")
                    success = process_video(entry["url"], DEFAULT_TID)
                    if success:
                        existing_url_list[i]["status"] = "yes"
                        print(f"视频 {entry['url']} 上传成功。")
                    else:
                        existing_url_list[i]["count"] += 1
                        print(f"视频 {entry['url']} 上传失败 (总尝试 {existing_url_list[i]['count']} 次)。")
                    save_url_list(existing_url_list) # 每次状态更新都保存
                else:
                    print(f"视频 {entry['url']} 已达到最大重试次数 ({entry['count']}次) 仍未上传成功，将跳过。")
            elif entry["status"] == "yes":
                pass # 已上传成功的视频跳过
            pending_uploads_count += 1 if entry["status"] == "no" else 0
        
        if pending_uploads_count == 0:
            print("所有已知的视频都已处理完毕。")
        else:
            print(f"仍有 {pending_uploads_count} 个视频等待上传或重试。")

        print(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] 等待 {MONITOR_INTERVAL_SECONDS} 秒后再次检查...")
        time.sleep(MONITOR_INTERVAL_SECONDS)

def main():
    """
    主函数，提供用户选择操作模式。
    """
    load_config() # 在程序启动时加载配置

    print("\n请选择模式:")
    print("1: 单视频上传模式")
    print("2: 视频列表或频道模式 (手动运行一次，获取视频列表并上传)")
    print("3: 断点续传模式 (手动运行一次，继续上传未完成的视频)")
    print("4: 自动监控模式 (自动监控 YouTube 播放列表/频道，并上传新视频)")
    mode = input("请输入模式编号: ")
    
    if mode == "1":
        mode_single_video()
    elif mode == "2":
        mode_video_list()
    elif mode == "3":
        mode_resume_upload()
    elif mode == "4":
        mode_auto_monitor() # 新增的自动监控模式入口
    else:
        print("无效的模式编号。")

if __name__ == "__main__":
    main()